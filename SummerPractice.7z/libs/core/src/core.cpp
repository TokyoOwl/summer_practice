#pragma once
#include <iostream>
namespace core{
    void base_function(){
        std::cout << "This is a base function!" << std::endl;
    }
}