namespace core{
    void base_function();
}
