namespace utils{
    void utility_function();
}