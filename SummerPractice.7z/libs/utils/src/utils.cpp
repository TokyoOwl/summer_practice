#pragma once
#include <iostream>
namespace utils{
    void utility_function(){
        std::cout << "This is an utility function!" << std::endl;
    }
}